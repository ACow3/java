package com.codingdojo.tvshows.services;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codingdojo.tvshows.models.Show;
import com.codingdojo.tvshows.models.User;
import com.codingdojo.tvshows.repositories.ShowRepository;
import com.codingdojo.tvshows.repositories.UserRepository;

@Service
public class AppService {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ShowRepository showRepository;

		// register user and hash their password

		public User registerUser(User user) {
			String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
			user.setPassword(hashed);
			return userRepository.save(user);
		}
		
		// find user by email
		public User findByEmail(String email) {
			return userRepository.findByEmail(email);
		}

		// find user by id
		public User findUserById(Long id) {
			Optional<User> u = userRepository.findById(id);

			if (u.isPresent()) {
				return u.get();
			} else {
				return null;
			}
		}

		// authenticate user

		public boolean authenticateUser(String email, String password) {
			// first find the user by email
			User user = userRepository.findByEmail(email);
			// if we can't find it by email, return false
			if (user == null) {
				return false;
			} else {

				// if the passwords match, return true, else, return false
				if (BCrypt.checkpw(password, user.getPassword())) {
					return true;
				} else {
					return false;
				}
			}
		}

		
		// returns all shows
		public List<Show> allShows() {
			return (List<Show>) showRepository.findAll();
		}
		
		// creates a show
		public @Valid Show createShow(@Valid Show show) {
			return showRepository.save(show);
		}
		
		// retrieves a show
		public Show findShow(Long id) {
			Optional<Show> optionalShow = showRepository.findById(id);
			if (optionalShow.isPresent()) {
				return optionalShow.get();
			} else {
				return null;
			}
		}
		
		// get all shows for current user
		public List<Show> getAllShows() {
			return showRepository.findAll();
		}
		
		public Show getOneShow(Long id) {
			Optional<Show> optionalShow = showRepository.findById(id);
			if(optionalShow.isPresent()) {
				return optionalShow.get();
			} else {
				
			}
			return null;
		}
		
		// updates show
		public void updateShow(@Valid Show show) {
			showRepository.save(show);
		}

		// deletes show
		public void deleteShow(Long id) {
			showRepository.deleteById(id);
		}
		
	}