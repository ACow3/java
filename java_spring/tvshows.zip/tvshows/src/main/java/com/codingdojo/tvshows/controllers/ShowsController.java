package com.codingdojo.tvshows.controllers;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.codingdojo.tvshows.models.Show;
import com.codingdojo.tvshows.services.AppService;

@Controller
public class ShowsController {
	@Autowired
	AppService appService;
	
	// show all shows
//	@GetMapping("/shows")
//	public String home(Model model) {
//		List<Show> allShows = appService.getAllShows();
//		model.addAttribute("Shows", allShows);
//		return "views/shows.jsp";
//	}
//	
	// render page to create new show
	@GetMapping("/shows/new")
	public String newShow(Model model) {
		model.addAttribute("song", new Show());
		return "views/new.jsp";
	}
	
	// process new show 
	@PostMapping("/shows/process")
	public String createNewShow(@Valid @ModelAttribute("show") Show show, BindingResult result) {
		if(result.hasErrors()) {
			return "views/shows.jsp";
		}
		appService.createShow(show);
		return "redirect:/shows";
	}
	
	// show one show
	@GetMapping("/shows/show/{id}")
	public String show(@PathVariable("id") Long id, Model model) {
		Show show = appService.getOneShow(id);
		model.addAttribute("Show", show);
		return "views/show.jsp";
	}
	
	// renders page to edit show
	@RequestMapping("/shows/{id}/edit")
	public String edit(@ModelAttribute("showObj") @PathVariable("id") Long id, Model model) {
		Show show = appService.findShow(id);
		model.addAttribute("show", show);
		return "views/edit.jsp";
	}
	
	// edit one show
	@PutMapping("/shows/{id}")
	public String update(@Valid @ModelAttribute("show") Show show, BindingResult result) {
		if (result.hasErrors()) {
			return "views/edit.jsp";
		} else {

			appService.createShow(show);
			return "redirect:/shows";
		}
	}
	
	// delete one show
	@DeleteMapping("/shows/{id}/delete")
	public String deleteShow(@PathVariable("id") Long id) {
		appService.deleteShow(id);
		return "redirect:/shows";
	}
}
