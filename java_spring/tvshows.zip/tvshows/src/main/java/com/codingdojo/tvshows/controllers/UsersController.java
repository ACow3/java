package com.codingdojo.tvshows.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.codingdojo.tvshows.models.Show;
import com.codingdojo.tvshows.models.User;
import com.codingdojo.tvshows.services.AppService;
import com.codingdojo.tvshows.validator.UserValidator;

@Controller
public class UsersController {
	private final AppService appService;

	private final UserValidator userValidator;

	public UsersController(AppService appService, UserValidator userValidator) {
		this.appService = appService;
		this.userValidator = userValidator;
	}

	// render login and registration page
	@RequestMapping("/")
	public String loginRegisterForm(@ModelAttribute("user") User user) {
		return "views/loginAndRegistration.jsp";
	}

	// processing/registering new user
	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
		userValidator.validate(user, result);
		if (result.hasErrors()) {
			return "views/loginAndRegistration.jsp";
		}
		User u = appService.registerUser(user);
		session.setAttribute("user", u);
		return "redirect:/shows";
	}

	// if the user is authenticated, save their user id in session
	// else, add error messages and return the login page

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginUser(@Valid @ModelAttribute("user") User user, @RequestParam("email") String email, @RequestParam("password") String password, RedirectAttributes error, Model model,
			HttpSession session) {
		boolean isAuthenticated = appService.authenticateUser(email, password);
		if (isAuthenticated) {
			User u = appService.findByEmail(email);
			session.setAttribute("user", u);
			return "redirect:/shows";
		} else {
			error.addFlashAttribute("error", "Invalid login. Try again.");
			model.addAttribute("error", "Invalid Credentials. Please try again.");
			return "views/loginAndRegistration.jsp";
		}
	}

	// get user from session, save them in the model and return the home page
	// show all shows
	@GetMapping("/shows")
	public String home(@ModelAttribute("show") Show show, HttpSession session, Model model) {
		if(session.getAttribute("user") == null) {
			return "redirect:/";
		}
		
		List<Show> allShows = appService.getAllShows();
		User user = (User) session.getAttribute("user");
		model.addAttribute("Shows", allShows);
		model.addAttribute("user", user);
		
//		Long user_id = (Long) user.getId();//		
		return "views/shows.jsp";
		
		
	}

	
	public UserValidator getUserValidator() {
		return userValidator;
	}

	public AppService getAppService() {
		return appService;
	}

	// invalidate session
	// redirect to login page
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	public AppService getUserService() {
		return appService;
	}
}