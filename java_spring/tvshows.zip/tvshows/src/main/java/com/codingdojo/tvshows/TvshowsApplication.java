package com.codingdojo.tvshows;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TvshowsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TvshowsApplication.class, args);
	}

}
