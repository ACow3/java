public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz fBuzz = new FizzBuzz();
        fBuzz.fizzBuzz(100);
    }
}