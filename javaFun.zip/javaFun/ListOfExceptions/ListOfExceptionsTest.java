public class ListsOfExceptionsTest{
    public static void main(String[] args){
        ListsOfExceptions exceptionTest = new ListsOfExceptions();
        exceptionTest.myTest();
    }
}