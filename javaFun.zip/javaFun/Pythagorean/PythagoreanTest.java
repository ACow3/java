public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean p = new Pythagorean();
        double answer = p.calculateHypotenuse(3, 4);
        System.out.println(answer);
    }
}