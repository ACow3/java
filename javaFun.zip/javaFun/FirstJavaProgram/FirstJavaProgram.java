public class FirstJavaProgram {
    public static void main(String[] args) {
        System.out.println("My name is Alex Cowling. I am 29 years old. My hometown is Benicia, CA.");
    }
}