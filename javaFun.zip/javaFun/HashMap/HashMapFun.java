import java.util.HashMap;
import java.util.Set;

public class HashMapFun {
    public static void main(String[] args) {
        HashMap<String, String> userMap = new HashMap<String, String>();
        // Four songs & lyrics
        userMap.put("Grindin' All My Life", "All my life, been grindin' all my life. Sacrificed, hustled, paid the price");
        userMap.put("Dedication", "Dedication, hard work plus patience. The sum of all my sacrifice, I'm done waitin'");
        userMap.put("Million While You Young", "You should try to do what we done. Make a million dollars while you young");
        userMap.put("Ocean Views", "Ocean views, small circle it's the chosen few. I wrote it down and I followed through");
        

        // One song's lyrics pulled by track name 
        String lyrics = userMap.get("Grindin' All My Life"); // .get(key)
        System.out.println("The track lyrics are: " + lyrics); // lyrics = value
        
        // get the keys by using the keySet method
        Set<String> keys = userMap.keySet();
        for(String key : keys) {
            System.out.println("Track: " + key);
            System.out.println("Lyrics: " + userMap.get(key));    
        }
    }
}

// HashMap<key, value> userMap = new HashMap<key, value>();
// HashMap<track, lyrics> userMap = new HashMap<track, lyrics>();