public class BasicJavaTest {
    public static void main(String[] args) {
        BasicJava testNumber = new BasicJava();

        testNumber.print1To255();

        testNumber.printOdd1To255();

        testNumber.printSum();

        int[] testArr = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.iterateArray(testArr);

        int[] testArr2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.findMax(testArr2);

        int[] testArr3 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.getAverage(testArr3);

        testNumber.arrayOddNumbers();

        int[] testArr4 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.greaterThanY(testArr4, 3);

        int[] testArr5 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.squareTheValues(testArr5);

        int[] testArr6 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.eliminateNegativeNumbers(testArr6);

        int[] testArr7 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.maxMinAvg(testArr7);

        int[] testArr8 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        testNumber.shiftingValues(testArr8);
    }
}
